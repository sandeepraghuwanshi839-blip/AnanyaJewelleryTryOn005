# Business Co-Founder AI — Android APK project

This is an APK-ready Android Studio/AndroidIDE project.

## Build
Open the project in Android Studio or AndroidIDE and build:
`app` -> `assembleDebug`

A GitHub Actions workflow is included to build the debug APK automatically.

## Important
The APK works in offline demo mode immediately. To use a hosted backend later, the HTML's BC_API_URL can be set to an HTTPS API URL. Never put private API keys in the APK.
